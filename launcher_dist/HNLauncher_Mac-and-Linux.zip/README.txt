Extract anywhere and run! You will be asked if you want to use Standard or Portable mode.

Standard mode will save all files in $HOME/.HostileNetworks/HNLauncher/.

Portable mode will save all files in current directory. If you intend to use Portable mode, be sure to put this into it's own folder that you have full write-access to.