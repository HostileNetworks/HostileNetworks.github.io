Hostile Networks Launcher is currently a "portable" mode app. It will put all it's files in the same folder as itself.

SO MAKE SURE TO EXTRACT THIS TO IT'S OWN FOLDER!

Extract the archive somewhere that has enough space to fit the modpack (a few GB). 