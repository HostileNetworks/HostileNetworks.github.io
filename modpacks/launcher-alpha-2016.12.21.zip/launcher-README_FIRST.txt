Initial versions of the Hostile Networks launcher are in PORTABLE mode.

Extract the jar to it's own NEW folder!